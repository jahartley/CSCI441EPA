# STM32 W5500 TEST

## TODO
- Fork Arduino Ethernet
    - https://github.com/arduino-libraries/Ethernet/tree/master
    - Kill unnecessary parts not relevant to this project, i.e. server support, W5100,W5200 etc support.
    - Verify that SPI CS pin can be changed during run time.
- Fork SdFat library for trimming for this project.
    - https://github.com/adafruit/SdFat
- Fork Adafruit_MAX31865
    - https://github.com/adafruit/Adafruit_MAX31865/tree/master
    - Remove need for Adafruit spi library.
    - verify that SPI CS can be changed during run time.
    - SEND OHMS DATA TO DATA PROCESSOR!!! saves space.

## Notes
- empty build is 7112 bytes, 10.9% of STM32F103C8 (64K Flash)
- adding Ethernet.h (no other code) 7380 bytes 11.3%
- NO DHCP Eth is 14576 bytes, 22.2%
- DHCP Eth is 25072 bytes 38.3%
- MQTT is 26492 bytes, 40.4%
- MQTT + DHCP is 33260 bytes 50.8%
- MQTT + DNS is 26568 bytes, 40.5%

- CDC SerialUSB 4376 bytes ram, 21372 bytes flash
- minimal sd card, 228 ram, 9040 flash


## PINS STM32F103C8 Blue Pill type C
- PB10 SDCARD CS
- PB11 ETH CS
- A5 SCLK1
- A6 MISO1
- A7 MOSI1

- PB8 CS1 SPI chip select 1
- PB13 CS2 SPI chip select 2
- PB14 CS3 SPI chip select 3
- PB15 CS4 SPI chip select 4

## SPI Types
The following lists the SPI devices with built in support, for use in sensor board config lines L12 to L15
- 0 NONE
- 1 BME280
- 2 PT100/1000 sensor using MAX31865 board

## SD Card file format
filename "TEST.TXT"
L1: DEADBEEFFEED MAC ADDRESS
L2: 10,0,70,25  host ip
L3: 10,0,31,23  DNS
L4: 10,0,70,1   gateway ip
L5: 255,255,255,0 Subnet mask
L6: 10,0,30,10  MQTT server 10.0.70.164
L7: 1883        MQTT port
L8: name        MQTT client name
L9: try         MQTT username
L10: try         MQTT password
L11: room1       Sensor Location
L12: SPI sensor 1 type from list, using spi cs 1
L13: SPI sensor 2 type from list, using spi cs 2
L14: SPI sensor 3 type from list, using spi cs 3
L15: SPI sensor 4 type from list, using spi cs 4
L16: Analog A0 type from MQTT list (or 0 for none.)
L17: Analog A1 type from MQTT list (or 0 for none.)
L18: Analog A2 type from MQTT list (or 0 for none.)
L19: Analog A3 type from MQTT list (or 0 for none.)

## Blink codes
01 Boot Start
02 SD begin ok
03 SD data read ok
04 ETH startup
05 W5500 reset and ETH init ok
06 ETH Startup complete/ok

11 SD.begin error, 2x followed by SD error code.
12 SD file open error, 2x followed by SD error code.
13 SD file fget failed
14 SD file line too long
15 SD file ip address error
16 SD file string error

21 Ethernet hardware not detected/incorrect (wiring to W5500)

41 MQTT connection timeout
42 MQTT connection lost
43 MQTT connection failed
44 MQTT disconnected
45 MQTT connected ok
46 MQTT Bad Protocol
47 MQTT Bad Client ID
48 MQTT Unavailable
49 MQTT Bad Credentials
50 MQTT Unauthorized

61 sensor 1 not found
62 sensor 2 not found
63 sensor 3 not found
64 sensor 4 not found


SD Card error codes.
SD_CARD_ERROR(CMD0, "Card reset failed") 
SD_CARD_ERROR(CMD2, "SDIO read CID") 
SD_CARD_ERROR(CMD3, "SDIO publish RCA") 
SD_CARD_ERROR(CMD6, "Switch card function") 
SD_CARD_ERROR(CMD7, "SDIO card select") 
SD_CARD_ERROR(CMD8, "Send and check interface settings") 
SD_CARD_ERROR(CMD9, "Read CSD data") 
SD_CARD_ERROR(CMD10, "Read CID data") 
SD_CARD_ERROR(CMD12, "Stop multiple block read") 
SD_CARD_ERROR(CMD13, "Read card status") 
SD_CARD_ERROR(CMD17, "Read single block") 
SD_CARD_ERROR(CMD18, "Read multiple blocks") 
SD_CARD_ERROR(CMD24, "Write single block") 
SD_CARD_ERROR(CMD25, "Write multiple blocks") 
SD_CARD_ERROR(CMD32, "Set first erase block") 
SD_CARD_ERROR(CMD33, "Set last erase block") 
SD_CARD_ERROR(CMD38, "Erase selected blocks") 
SD_CARD_ERROR(CMD58, "Read OCR register") 
SD_CARD_ERROR(CMD59, "Set CRC mode") 
SD_CARD_ERROR(ACMD6, "Set SDIO bus width") 
SD_CARD_ERROR(ACMD13, "Read extended status") 
SD_CARD_ERROR(ACMD23, "Set pre-erased count") 
SD_CARD_ERROR(ACMD41, "Activate card initialization") 
SD_CARD_ERROR(ACMD51, "Read SCR data")

## MQTT Sensor Types
- 1 temperature in F, decimal degrees with two decimal places
- 2 relative humidity in percent, decimal percent with two decimal places
- 3 barometric air pressure in pascals, decimal, with zero decimal places. (101325 Pa is standard atmospheric pressure)
- 4 Max analog value.
- 5 H2S gas sensor reading, in volts from MQ136 sensor, RL (10k onboard, 14.7k in divider) = 5.95k ohms.
- 6NH3 gas sensor reading, in volts from MQ136 sensor, RL (10k onboard, 14.7k in divider) = 5.95k ohms.
