/**
 * Copyright (c) 2024 Judson Hartley
 * This file is part of the blink code library for arduino error messages.
 *
 * MIT License
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include "blinkCode.h"
void blinkCode(uint8_t t, int8_t repeat){
  //blue pill type c board, ledpin is PB2, High is on...
  #define TON 500
  #define TOFF 200
  #define OON 200
  #define OOFF 200
  #define TOPAUSE 500
  #define OTREPEAT 1000
  #ifndef BLINK_PIN
  #define BLINK_PIN LED_BUILTIN
  #endif
  if (t > 99) return;
  pinMode(BLINK_PIN, OUTPUT);
  digitalWrite(BLINK_PIN, LOW);
  delay((OTREPEAT - TOFF));
  for (int i = 0; i < ( (t / 10) % 10 ); i++){
    delay(TOFF);
    digitalWrite(BLINK_PIN, HIGH);
    delay(TON);
    digitalWrite(BLINK_PIN, LOW);
  }
  delay((TOPAUSE - OOFF));
  for (int i = 0; i < ( t % 10 ); i++){
    delay(OOFF);
    digitalWrite(BLINK_PIN, HIGH);
    delay(OON);
    digitalWrite(BLINK_PIN, LOW);
  }
  if (repeat > 1 ) blinkCode(t, repeat - 1);
  if (repeat < 0) blinkCode(t, repeat);
  return;
}

void blinkCode(uint8_t t) {
    blinkCode(t, -1);
}