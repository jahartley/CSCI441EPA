/**
 * Copyright (c) 2024 Judson Hartley
 * This file is part of the blink code library for arduino error messages.
 *
 * MIT License
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#ifndef blinkCode_h
#define blinkCode_h
#include <Arduino.h>

#define BLINK_PIN PB2 //blink pin for type c blue pill stm32f103c8

/**
 * @brief blink error codes, up to 99 codes. tens column blinks slow, pause, then fast for ones.
 * @note Use #define BLINK_PIN YOUR_LED_PIN if LED_BUILTIN is not connected to the led pin.
 * @author Judson Hartley 2024
 * @param t code to blink, 1 to 99
 * @param repeat number of times to blink the code. NEGATIVE values HALT code by infinite loop
 */
void blinkCode(uint8_t t, int8_t repeat);

/**
 * @brief blink error codes, up to 99 codes. tens column blinks slow, pause, then fast for ones.
 * @note Use #define BLINK_PIN YOUR_LED_PIN if LED_BUILTIN is not connected to the led pin.
 * @author Judson Hartley 2024
 * @param t code to blink, 1 to 99
 * @param repeat is set to -1, causing an infinite loop
 */
void blinkCode(uint8_t t);
#endif