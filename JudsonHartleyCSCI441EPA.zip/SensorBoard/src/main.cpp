#include <Arduino.h>

//#define J_USB_SER //enable serial output
#define J_SD_MIN //enable SD Card
#define J_ETH //enable ethernet
#define J_BME //enable BME280
#define MAX_SPI_SENSORS 4
#define MAX_ANALOG_SENSORS 4

#include "blinkCode.h"
#define BLINK_PIN PB2 //blink pin for type c blue pill stm32f103c8

//pin defs.
#define ETH_CS_PIN PB11
#define ETH_RESET_PIN PB9
#define SDC_CS_PIN PB10
//#define BME280_CS_PIN PB8

#define CS1_PIN PB8 //PB12
#define CS2_PIN PB13
#define CS3_PIN PB14
#define CS4_PIN PB15

//SPI Sensor variables
int spiSensorType[MAX_SPI_SENSORS] = {};
long lastSpiSensorTime, spiSensorInterval = 500; //sensor interval is ms, times 4, i.e.: 500 results in one read per sensor every 2 seconds.
int spiSensorLoopCount = 0;

//analog sensor variables
int analogSensorType[MAX_ANALOG_SENSORS] = {};

long lastAnalogSensorTime, analogSensorInterval = 500; //sensor interval is ms, times 4, i.e.: 500 results in one read per sensor every 2 seconds.
int analogSensorLoopCount = 0;

char addr[20];
char buffer[60];

byte mac[6]; //mac address


uint16_t port;
char cname[15];
char uname[15];
char pwrd[15];
char type[10];
char location[15];

uint32_t strToIPint(char* str){
  char sep[] = ".";
  char* token;
  int adr;
  uint32_t adr2 = 0;
  token = strtok(str, sep);
  for (int i = 0; i < 4; i++){
    adr = atoi(token);
    uint32_t mul;
    if (i == 0) mul = 1;
    if (i == 1) mul = 256;
    if (i == 2) mul = 256 * 256;
    if (i == 3) mul = 256 * 256 * 256;
    adr2 += adr * mul;
    token = strtok(NULL, sep);
    if (token == NULL && i < 3) return false;
  }
  return adr2;
}

#ifdef J_USB_SER
void serr(char* s) {
  Serial.println(s);
}
#else
  #define serr(s) (void)0
#endif


#ifdef J_ETH
#include <Ethernet.h>
#include <PubSubClient.h>
int counterA = 0;
int counterB = 0;
IPAddress addresses[5] = {(uint32_t)0,(uint32_t)0,(uint32_t)0,(uint32_t)0,(uint32_t)0};
EthernetClient ethClient;
PubSubClient client(ethClient);

void mqttPub(char* m, char* p) {
  client.publish(m,p);
}

void reconnect() {
  // Loop until we're reconnected
  while (!client.connected()) {
    // Attempt to connect
    if (client.connect(cname, uname, pwrd)) {
    } else {
      int errcd = client.state();
      blinkCode(errcd + 45, 5);
    }
  }
}

void blinkIp(IPAddress ip){
  blinkCode(ip[0],1);
  blinkCode(ip[1],1);
  blinkCode(ip[2],1);
  blinkCode(ip[3],1);
}

void mqttStartup() {
  //WIZNET RESET AND INITIALIZE
    digitalWrite(ETH_RESET_PIN, LOW);   // reset the WIZ820io
    delay(50);
    digitalWrite(ETH_RESET_PIN, HIGH);   // reset the WIZ820io
    delay(10);
  Ethernet.init(ETH_CS_PIN);
  blinkCode(5,1);
  client.setServer(addresses[4], port);
  Ethernet.begin(mac, addresses[0],addresses[1],addresses[2],addresses[3]);
  //Ethernet.begin(mac, host, dns, gateway, subnet);
  // Check for Ethernet hardware present
  if (Ethernet.hardwareStatus() != EthernetW5500) {
    blinkCode(21);
  }
  blinkCode(6,1);
}

bool getIP(IPAddress* ip, char* str) {
  *ip = strToIPint(str);
  return true;
}

void printIP(IPAddress ip) {
  serr("PRINTING IP");
  itoa(ip[0],addr,10);
  serr(addr);
  serr(".");
  itoa(ip[1],addr,10);
  serr(addr);
  serr(".");
  itoa(ip[2],addr,10);
  serr(addr);
  serr(".");
  itoa(ip[3],addr,10);
  serr(addr);  
}
#else
void mqttPub(char* m, char* p) {
  serr(m);
  serr(p);
}
uint32_t addresses[5] = {};

bool getIP(uint32_t* ip, char* str) {
  *ip = strToIPint(str);
  return true;
}

void printIP(uint32_t ip) {
  serr("PRINTING IP");
  itoa(ip,addr,10);
  serr(addr);
}
#endif

#ifdef J_SD_MIN
#include "SdFat.h"

// 1 for FAT16/FAT32, 2 for exFAT, 3 for FAT16/FAT32 and exFAT.
#define SD_FAT_TYPE 1
/*
  Change the value of SD_CS_PIN if you are using SPI and
  your hardware does not use the default value, SS.
  Common values are:
  Arduino Ethernet shield: pin 4
  Sparkfun SD shield: pin 8
  Adafruit SD shields and modules: pin 10
*/
const uint8_t SD_CS_PIN = SDC_CS_PIN;
// Try max SPI clock for an SD. Reduce SPI_CLOCK if errors occur.
#define SPI_CLOCK SD_SCK_MHZ(5)

//#define ENABLE_DEDICATED_SPI 1
//Try to select the best SD card configuration.
#if HAS_SDIO_CLASS
#define SD_CONFIG SdioConfig(FIFO_SDIO)
#elif ENABLE_DEDICATED_SPI
#define SD_CONFIG SdSpiConfig(SD_CS_PIN, DEDICATED_SPI, SPI_CLOCK)
#else  // HAS_SDIO_CLASS
#define SD_CONFIG SdSpiConfig(SD_CS_PIN, SHARED_SPI, SPI_CLOCK)
#endif  // HAS_SDIO_CLASS

// #if SD_FAT_TYPE == 0
// SdFat sd;
// File file;
// #elif SD_FAT_TYPE == 1
// SdFat32 sd;
// File32 file;
// #elif SD_FAT_TYPE == 2
// SdExFat sd;
// ExFile file;
// #elif SD_FAT_TYPE == 3
// SdFs sd;
// FsFile file;
// #else  // SD_FAT_TYPE
// #error Invalid SD_FAT_TYPE
// #endif  // SD_FAT_TYPE

SdFat32 sd;
File file;

char line[40];

//------------------------------------------------------------------------------
// Check for extra characters in field or find minus sign.
char* skipSpace(char* str) {
  while (isspace(*str)) str++;
  return str;
}
//------------------------------------------------------------------------------
bool getMac(byte bin[], char* str){
  for (size_t i = 0; str[i] and str[i + 1]; i += 2) {
    char slice[] = {0, 0, 0};
    strncpy(slice, str + i, 2);
    bin[i / 2] = strtol(slice, nullptr, 16);
  }
  return true;
}


bool readSetup() {
  #ifdef J_SD_MIN
  //Initialize the SD.
  blinkCode(1,1);
  while (true) {
    if (!sd.begin(SD_CONFIG)) {
      serr("sd begin failed");
      blinkCode(11, 2);
      blinkCode(sd.sdErrorCode(),3);
      continue;
    }
    blinkCode(2,1);
    if (!file.open("TEST.TXT")) {
      serr("open failed");
      blinkCode(12, 2);
      blinkCode(sd.sdErrorCode(),3);
      continue;
    } else break;
  }
  serr("StartCardRead");
  int count = 0;
  while (file.available()) {
    count++;
    int n = file.fgets(line, sizeof(line));
    if (n <= 0) {
      serr("fgets failed");
      blinkCode(13);
    }
    if (line[n - 1] != '\n' && n == (sizeof(line) - 1)) {
      serr("line too long");
      blinkCode(14);
    }
    line[n-1] = '\0';
    if (count == 1) {
      serr(line);
      getMac(mac, line);
      #ifdef J_USB_SER
      itoa(mac[0], addr, 16);
      serr(addr);
      serr(":");
      itoa(mac[1], addr, 16);
      serr(addr);
      serr(":");
      itoa(mac[2], addr, 16);
      serr(addr);
      serr(":");
      itoa(mac[3], addr, 16);
      serr(addr);
      serr(":");
      itoa(mac[4], addr, 16);
      serr(addr);
      serr(":");
      itoa(mac[5], addr, 16);
      serr(addr);
      #endif
      continue;
    }
    if (count == 2) {
      if (!getIP(&addresses[0], line)) blinkCode(15);
      #ifdef J_USB_SER
      printIP(addresses[0]);
      #endif
      continue;
    }
    if (count == 3) {
      if (!getIP(&addresses[1], line)) blinkCode(15);
      #ifdef J_USB_SER
      printIP(addresses[1]);
      #endif
      continue;
    }
    if (count == 4) {
      if (!getIP(&addresses[2], line)) blinkCode(15);
      #ifdef J_USB_SER
      printIP(addresses[2]);
      #endif
      continue;
    }
    if (count == 5) {
      if (!getIP(&addresses[3], line)) blinkCode(15);
      #ifdef J_USB_SER
      printIP(addresses[3]);
      #endif
      continue;
    }
    if (count == 6) {
      if (!getIP(&addresses[4], line)) blinkCode(15);
      #ifdef J_USB_SER
      printIP(addresses[4]);
      #endif
      continue;
    }
    if (count == 7) {
      port = atoi(line);
      #ifdef J_USB_SER
      itoa(port, addr, 10);
      Serial.println(addr);
      #endif
      continue;
    }
    if (count == 8) {
      if (n > 14) blinkCode(16);
      strcpy(cname, line);
      serr(cname);
      continue;
    }
    if (count == 9) {
      if (n > 14) blinkCode(16);
      strcpy(uname, line);
      serr(uname);
      continue;
    }
    if (count == 10) {
      if (n > 14) blinkCode(16);
      strcpy(pwrd, line);
      serr(pwrd);
      continue;
    }
    if (count == 11) {
      if (n > 14) blinkCode(16);
      strcpy(location, line);
      serr(location);
      continue;
    }
    if (count > 11 && count < (11 + MAX_SPI_SENSORS)) {
      spiSensorType[(count - 12)] = atoi(line);
      continue;
    }
    if (count > (11 + MAX_SPI_SENSORS) && count < (11 + MAX_SPI_SENSORS + MAX_ANALOG_SENSORS)) {
      analogSensorType[(count - (12 + MAX_SPI_SENSORS))] = atoi(line);
      continue;
    }
    if (count > (11 + MAX_SPI_SENSORS + MAX_ANALOG_SENSORS)) {
      break;
    }
  }
  //file.close(); //no writes made, useless...
  sd.end();
  blinkCode(3,1);
  serr("Card Read Complete");
  #endif
  return true;
}
#endif

#ifdef J_BME
#include <BME280Spi.h>
//int bmePin = csPinArray[1];
BME280Spi::Settings settings0(CS1_PIN);
BME280Spi::Settings settings1(CS2_PIN);
BME280Spi::Settings settings2(CS3_PIN);
BME280Spi::Settings settings3(CS4_PIN);

BME280Spi bmeArr[4] = {BME280Spi(settings0),BME280Spi(settings1),BME280Spi(settings2),BME280Spi(settings3)};

// BME280Spi bme0(settings0);
// BME280Spi bme1(settings1);
// BME280Spi bme2(settings2);
// BME280Spi bme3(settings3);
BME280::TempUnit tempUnit(BME280::TempUnit_Fahrenheit);
BME280::PresUnit presUnit(BME280::PresUnit_Pa);
float tempF=-999.99, humRH=-999.99, presPA=-999.99;

void readBME(int which){
  bmeArr[which].read(presPA, tempF, humRH, tempUnit, presUnit);
  dtostrf(tempF,5,2,addr);
  strcpy(buffer, "hvac/sensor/1/");
  strcat(buffer, location);
  mqttPub(buffer, addr);
  dtostrf(humRH,3,2,addr);
  strcpy(buffer, "hvac/sensor/2/");
  strcat(buffer, location);
  mqttPub(buffer, addr);
  dtostrf(presPA,7,0,addr);
  strcpy(buffer, "hvac/sensor/3/");
  strcat(buffer, location);
  mqttPub(buffer, addr);
}
#endif

bool spiSetupType(int which) {
  if (spiSensorType[which] == 0) return true;
  #ifdef J_BME //BME280
  if (spiSensorType[which] == 1) {
    return bmeArr[which].begin();
  }
  #endif
  return true;
}

void spiReadSensor(int which) {
  if (spiSensorType[which] == 0) return;
  #ifdef J_BME //BME280
  if (spiSensorType[which] == 1) {
    readBME(which);
  }
  #endif
}

void analogReadSensor(int which) {
  serr("analogReadSensor");
  itoa(which, addr, 10);
  serr(addr);
  itoa(analogSensorType[which], addr, 10);
  serr(addr);
  if (analogSensorType[which] == 0) return;
  int val = analogRead((192 + which));
  strcpy(buffer, "hvac/sensor/");
  itoa(analogSensorType[which], addr, 10);
  strcat(buffer, addr);
  strcat(buffer, "/");
  strcat(buffer, location);
  itoa(val, addr, 10);
  mqttPub(buffer, addr);
}

//------------------------------------------------------------------------------
void setup() {
  #ifdef J_USB_SER
  Serial.begin(9600);
  while (!Serial) {
    yield();
  }
  #endif
  pinMode(ETH_CS_PIN, OUTPUT);
  pinMode(SDC_CS_PIN, OUTPUT);
  pinMode(ETH_RESET_PIN, OUTPUT);
  digitalWrite(ETH_RESET_PIN, HIGH);
  digitalWrite(ETH_CS_PIN, HIGH);
  digitalWrite(SDC_CS_PIN, HIGH);
  readSetup();
  blinkCode(4,1);
  digitalWrite(SDC_CS_PIN, HIGH);
  #ifdef J_ETH
  mqttStartup();
  #endif
  for (int i = 0; i < 4; i++){
    while (!spiSetupType(i))
    {
      blinkCode(61,(i+1));
    }
    
  }
}


long lastMillis, thisLoopMillis;


void loop() {
  thisLoopMillis = millis();
  #ifdef J_ETH
	
	if (!client.connected()) {
		reconnect();
	}
  client.loop();
  #endif

  if (thisLoopMillis - lastSpiSensorTime > spiSensorInterval){
    lastSpiSensorTime = thisLoopMillis;
    if (spiSensorLoopCount >= MAX_SPI_SENSORS) {
      spiSensorLoopCount = 0;
    } else {
      spiSensorLoopCount++;
    }
    spiReadSensor(spiSensorLoopCount);
  }

  if (thisLoopMillis - lastAnalogSensorTime > analogSensorInterval){
    lastAnalogSensorTime = thisLoopMillis;
    if (analogSensorLoopCount >= MAX_ANALOG_SENSORS) {
      analogSensorLoopCount = 0;
    } else {
      analogSensorLoopCount++;
    }
    analogReadSensor(analogSensorLoopCount);
  }

  // publish a heartbeat message roughly every 3 seconds.
	if (thisLoopMillis - lastMillis > 3000) {
		lastMillis = thisLoopMillis;
		
    #ifdef J_ETH
		// itoa(Ethernet.localIP()[3], addr, 10);
		// client.publish("hvac/heartbeat/hvac1addr", addr);
		// client.publish("hvac/heartbeat/hvac1type", type);
    
    if (counterB > 3) {
      counterB = 0;
      counterA++;
    }
    if (counterA > 4) counterA = 0;

    itoa(addresses[counterA][counterB],addr,10);
    counterB++;
    mqttPub("hvac/heartbeat", addr);
    #endif
	}
}