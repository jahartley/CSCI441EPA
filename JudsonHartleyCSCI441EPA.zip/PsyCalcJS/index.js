


console.log("-------------------------------------------------");
const {client} = require("./global.js");
const PsychroCalc = require('./psychrometricCalc.js');

const officePsy = new PsychroCalc("Office");
const outsidePsy = new PsychroCalc("Outside");
const greenHousePsy = new PsychroCalc("GreenHouse");

client.on('connect', () => {
    client.subscribe('hvac/#');
    client.subscribe('rtl_433/#');
})



client.on('message', function(topic, message) {
    let topicString = topic.toString();
    let topicArray = topicString.split("/");
    if (topicArray[0] == "rtl_433") {
        //console.log(topicArray);
        let msg = JSON.parse(message);
        //console.log(msg);
        if (msg?.id == 1430 && msg?.message_type == 56) {
            client.publish("hvac/sensor/1/outside", msg?.temperature_F.toString());
            client.publish("hvac/sensor/2/outside", msg?.humidity.toString());
            return;
        }
        if (msg?.id == 36) {
            client.publish("hvac/sensor/1/greenhouse", msg?.temperature_F.toString());
            client.publish("hvac/sensor/2/greenhouse", msg?.humidity.toString());
            return;
        }
    }

    if (topicArray[1] == "sensor") {
        if (topicArray[2] == "1") { //tempF
            if (topicArray[3] == "room1a") {
                officePsy.setTempF(parseFloat(message));
                return;
            }
            if (topicArray[3] == "outside") {
                outsidePsy.setTempF(parseFloat(message));
                return;
            }
            if (topicArray[3] == "greenhouse") {
                greenHousePsy.setTempF(parseFloat(message));
                return;
            }
        }
        if (topicArray[2] == "2") { //humidityRH
            if (topicArray[3] == "room1a") {
                officePsy.setHumidityRH(parseFloat(message));
                return;
            }
            if (topicArray[3] == "outside") {
                outsidePsy.setHumidityRH(parseFloat(message));
                return;
            }
            if (topicArray[3] == "greenhouse") {
                greenHousePsy.setHumidityRH(parseFloat(message));
                return;
            }
        }
        if (topicArray[2] == "3") { //pressurePa
            if (topicArray[3] == "room1a") {
                officePsy.setPressurePa(parseFloat(message));
                outsidePsy.setPressurePa(parseFloat(message));
                greenHousePsy.setPressurePa(parseFloat(message));
            }
        }
    }
});
