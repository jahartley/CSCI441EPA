const mqtt = require('mqtt');
const client = mqtt.connect('mqtt://10.0.30.10');

module.exports = { client };